from random import *
from tkinter import *
from tkinter import messagebox

# Variables
joueur={}
croupier={}
main_joueur=[]
main_croupier=[]
mise=0
paquet=[]
c=0
c2=0
j=0
j2=0
argent=0
victoires=0
#--------------------------------------

# Joueur + le croupier
def creer_participants():
    global joueur,croupier

    joueur = {
    "nom": "Vous",
    "main": [],
    "argent": argent,
    "perdu": False,
    "gagne": False,
    "egalite": False,
    }

    croupier = {
    "nom": "Croupier",
    "main": [],
    }
#--------------------------------------

# Tirer une carte
def tirer_carte():
    global paquet,carte

    x=choice(paquet)
    carte=paquet[x]
    paquet.remove(paquet[x])
    return carte
#--------------------------------------

# Distribuer les carte
def distribuer():
    global paquet,joueur,croupier,main_joueur,main_croupier,carte,can,fen1,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,c,c2,j,j2

    # Distribue une carte au joueur
    tirer_carte()

    if carte==1:
        fen3=Tk()

        w=275
        h=90

        ws=fen3.winfo_screenwidth()
        hs=fen3.winfo_screenheight()

        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)

        fen3.geometry('%dx%d+%d+%d' % (w, h, x, y))
        fen3.title("Valeur de l'as")
        fen3.overrideredirect(True)

        text=Label(fen3,text="Quelle valeur voulez-vous donner à votre as ?")
        text.place(relx=.5, rely=.15, anchor="c")

        def valeur_as_1():
            global carte,can,fen1,cartes_1,j,j2

            carte=1

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j=+75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        def valeur_as_11():
            global carte,can,fen1,cartes_1,j,j2

            carte=11

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        bouton1=Button(fen3,text="1",width=5,command=valeur_as_1)
        bouton1.place(relx=.35, rely=.6, anchor="c")
        bouton2=Button(fen3,text="11",width=5,command=valeur_as_11)
        bouton2.place(relx=.65, rely=.6, anchor="c")

        fen3.attributes("-topmost", True)

    else:
        main_joueur.append(carte)
        joueur["main"]=main_joueur

        if carte==2:
            x=choice(cartes_2)
            y=cartes_2.index(x)
            cartes_2.remove(cartes_2[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==3:
            x=choice(cartes_3)
            y=cartes_3.index(x)
            cartes_3.remove(cartes_3[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==4:
            x=choice(cartes_4)
            y=cartes_4.index(x)
            cartes_4.remove(cartes_4[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==5:
            x=choice(cartes_5)
            y=cartes_5.index(x)
            cartes_5.remove(cartes_5[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==6:
            x=choice(cartes_6)
            y=cartes_6.index(x)
            cartes_6.remove(cartes_6[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==7:
            x=choice(cartes_7)
            y=cartes_7.index(x)
            cartes_7.remove(cartes_7[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==8:
            x=choice(cartes_8)
            y=cartes_8.index(x)
            cartes_8.remove(cartes_8[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==9:
            x=choice(cartes_9)
            y=cartes_9.index(x)
            cartes_9.remove(cartes_9[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==10:
            x=choice(cartes_10)
            y=cartes_10.index(x)
            cartes_10.remove(cartes_10[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

    #--------------------------------------

    # Distribue une carte au croupier
    tirer_carte()

    if carte==1:
        def valeur_as_1():
            global carte,cartes_1,c,c2

            carte=1

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(c,c2,image=x,anchor=NW)

        def valeur_as_11():
            global carte,cartes_1,c,c2

            carte=11

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(c,c2,image=x,anchor=NW)

        if sum(main_croupier)+11>21:
            valeur_as_1()

            main_croupier.append(carte)
            croupier["main"]=main_croupier

            can.delete("score2")
            can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")

        if sum(main_croupier)+11<=21:
            valeur_as_11()

            main_croupier.append(carte)
            croupier["main"]=main_croupier

            can.delete("score2")
            can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")

    else:
        main_croupier.append(carte)
        croupier["main"]=main_croupier

        if carte==2:
            x=choice(cartes_2)
            y=cartes_2.index(x)
            cartes_2.remove(cartes_2[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==3:
            x=choice(cartes_3)
            y=cartes_3.index(x)
            cartes_3.remove(cartes_3[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==4:
            x=choice(cartes_4)
            y=cartes_4.index(x)
            cartes_4.remove(cartes_4[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==5:
            x=choice(cartes_5)
            y=cartes_5.index(x)
            cartes_5.remove(cartes_5[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==6:
            x=choice(cartes_6)
            y=cartes_6.index(x)
            cartes_6.remove(cartes_6[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==7:
            x=choice(cartes_7)
            y=cartes_7.index(x)
            cartes_7.remove(cartes_7[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==8:
            x=choice(cartes_8)
            y=cartes_8.index(x)
            cartes_8.remove(cartes_8[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==9:
            x=choice(cartes_9)
            y=cartes_9.index(x)
            cartes_9.remove(cartes_9[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==10:
            x=choice(cartes_10)
            y=cartes_10.index(x)
            cartes_10.remove(cartes_10[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75
    #--------------------------------------

    # Distribue une carte au joueur
    tirer_carte()

    if carte==1:
        fen3=Tk()

        w=275
        h=90

        ws=fen3.winfo_screenwidth()
        hs=fen3.winfo_screenheight()

        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)

        fen3.geometry('%dx%d+%d+%d' % (w, h, x, y))
        fen3.title("Valeur de l'as")
        fen3.overrideredirect(True)

        text=Label(fen3,text="Quelle valeur voulez-vous donner à votre as ?")
        text.place(relx=.5, rely=.15, anchor="c")

        def valeur_as_1():
            global carte,can,fen1,cartes_1,j,j2

            carte=1

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        def valeur_as_11():
            global carte,can,fen1,cartes_1,j,j2

            carte=11

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        bouton1=Button(fen3,text="1",width=5,command=valeur_as_1)
        bouton1.place(relx=.35, rely=.6, anchor="c")
        bouton2=Button(fen3,text="11",width=5,command=valeur_as_11)
        bouton2.place(relx=.65, rely=.6, anchor="c")

        fen3.attributes("-topmost", True)

    else:
        main_joueur.append(carte)
        joueur["main"]=main_joueur

        if carte==2:
            x=choice(cartes_2)
            y=cartes_2.index(x)
            cartes_2.remove(cartes_2[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==3:
            x=choice(cartes_3)
            y=cartes_3.index(x)
            cartes_3.remove(cartes_3[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==4:
            x=choice(cartes_4)
            y=cartes_4.index(x)
            cartes_4.remove(cartes_4[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==5:
            x=choice(cartes_5)
            y=cartes_5.index(x)
            cartes_5.remove(cartes_5[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==6:
            x=choice(cartes_6)
            y=cartes_6.index(x)
            cartes_6.remove(cartes_6[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==7:
            x=choice(cartes_7)
            y=cartes_7.index(x)
            cartes_7.remove(cartes_7[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==8:
            x=choice(cartes_8)
            y=cartes_8.index(x)
            cartes_8.remove(cartes_8[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==9:
            x=choice(cartes_9)
            y=cartes_9.index(x)
            cartes_9.remove(cartes_9[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==10:
            x=choice(cartes_10)
            y=cartes_10.index(x)
            cartes_10.remove(cartes_10[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

    can.delete("score")
    can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

    can.delete("score2")
    can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")

    bouton_double_mise.config(state="normal")
    #--------------------------------------
#--------------------------------------

# Double miser
def double_mise():
    global joueur,mise,can,bouton_double_mise

    joueur["argent"]-=mise

    mise+=mise

    can.delete("texte2")
    can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte2")

    can.delete("texte4")
    can.create_text(150,555,fill="white",font=("Purisa",14),text="Votre mise: "+str(round(mise,2))+" €",tag="texte4")

    bouton_double_mise.config(state=DISABLED)
#--------------------------------------

# Donne une carte au joueur
def carte_joueur():
    global paquet,joueur,main_joueur,can,fen1,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,j,j2,bouton_carte,mise_initiale

    tirer_carte()

    if carte==1:
        fen3=Tk()

        w=275
        h=90

        ws=fen3.winfo_screenwidth()
        hs=fen3.winfo_screenheight()

        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)

        fen3.geometry('%dx%d+%d+%d' % (w, h, x, y))
        fen3.title("Valeur de l'as")
        fen3.overrideredirect(True)

        text=Label(fen3,text="Quelle valeur voulez-vous donner à votre as ?")
        text.place(relx=.5, rely=.15, anchor="c")

        def valeur_as_1():
            global carte,can,fen1,cartes_1,j,j2

            carte=1

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        def valeur_as_11():
            global carte,can,fen1,cartes_1,j,j2

            carte=11

            main_joueur.append(carte)
            joueur["main"]=main_joueur

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

            can.delete("score")
            can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

            fen3.destroy()

        bouton1=Button(fen3,text="1",width=5,command=valeur_as_1)
        bouton1.place(relx=.35, rely=.6, anchor="c")
        bouton2=Button(fen3,text="11",width=5,command=valeur_as_11)
        bouton2.place(relx=.65, rely=.6, anchor="c")

        fen3.attributes("-topmost", True)

    else:
        main_joueur.append(carte)
        joueur["main"]=main_joueur

        if carte==2:
            x=choice(cartes_2)
            y=cartes_2.index(x)
            cartes_2.remove(cartes_2[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==3:
            x=choice(cartes_3)
            y=cartes_3.index(x)
            cartes_3.remove(cartes_3[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==4:
            x=choice(cartes_4)
            y=cartes_4.index(x)
            cartes_4.remove(cartes_4[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==5:
            x=choice(cartes_5)
            y=cartes_5.index(x)
            cartes_5.remove(cartes_5[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==6:
            x=choice(cartes_6)
            y=cartes_6.index(x)
            cartes_6.remove(cartes_6[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==7:
            x=choice(cartes_7)
            y=cartes_7.index(x)
            cartes_7.remove(cartes_7[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==8:
            x=choice(cartes_8)
            y=cartes_8.index(x)
            cartes_8.remove(cartes_8[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==9:
            x=choice(cartes_9)
            y=cartes_9.index(x)
            cartes_9.remove(cartes_9[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

        if carte==10:
            x=choice(cartes_10)
            y=cartes_10.index(x)
            cartes_10.remove(cartes_10[y])

            can.create_image(j,j2,image=x,anchor=NW)
            j+=75

    if mise==mise_initiale*2:
        bouton_carte.config(state=DISABLED)

    if j+75>1000 or sum(main_joueur)>21 or sum(main_joueur)==21:
        bouton_carte.config(state=DISABLED)

    can.delete("score")
    can.create_text(500,425,fill="white",font=("Purisa",14),text="Votre score: "+str(sum(main_joueur)),tag="score")

    bouton_double_mise.config(state=DISABLED)
#--------------------------------------

# Donne une carte au croupier
def carte_croupier():
    global paquet,croupier,main_croupier,can,fen1,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,c,c2

    tirer_carte()

    if carte==1:
        def valeur_as_1():
            global carte,cartes_1,c,c2

            carte=1

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(c,c2,image=x,anchor=NW)

        def valeur_as_11():
            global carte,cartes_1,c,c2

            carte=11

            x=choice(cartes_1)
            y=cartes_1.index(x)
            cartes_1.remove(cartes_1[y])

            can.create_image(c,c2,image=x,anchor=NW)

        if sum(main_croupier)+11>21:
            valeur_as_1()

            main_croupier.append(carte)
            croupier["main"]=main_croupier

            can.delete("score2")
            can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")

        if sum(main_croupier)+11<=21:
            valeur_as_11()

            main_croupier.append(carte)
            croupier["main"]=main_croupier

            can.delete("score2")
            can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")

    else:
        main_croupier.append(carte)
        croupier["main"]=main_croupier

        if carte==2:
            x=choice(cartes_2)
            y=cartes_2.index(x)
            cartes_2.remove(cartes_2[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==3:
            x=choice(cartes_3)
            y=cartes_3.index(x)
            cartes_3.remove(cartes_3[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==4:
            x=choice(cartes_4)
            y=cartes_4.index(x)
            cartes_4.remove(cartes_4[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==5:
            x=choice(cartes_5)
            y=cartes_5.index(x)
            cartes_5.remove(cartes_5[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==6:
            x=choice(cartes_6)
            y=cartes_6.index(x)
            cartes_6.remove(cartes_6[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==7:
            x=choice(cartes_7)
            y=cartes_7.index(x)
            cartes_7.remove(cartes_7[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==8:
            x=choice(cartes_8)
            y=cartes_8.index(x)
            cartes_8.remove(cartes_8[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==9:
            x=choice(cartes_9)
            y=cartes_9.index(x)
            cartes_9.remove(cartes_9[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        if carte==10:
            x=choice(cartes_10)
            y=cartes_10.index(x)
            cartes_10.remove(cartes_10[y])

            can.create_image(c,c2,image=x,anchor=NW)

            c+=75

        can.delete("score2")
        can.create_text(500,165,fill="white",font=("Purisa",14),text="Score du croupier: "+str(sum(main_croupier)),tag="score2")
#--------------------------------------

# Fait miser le joueur
def miser():
    global mise,joueur,argent,fen1,fen2,can,carte,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,mise_initiale
    fen2=Tk()

    w=275
    h=90

    ws=fen2.winfo_screenwidth()
    hs=fen2.winfo_screenheight()

    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)

    fen2.geometry('%dx%d+%d+%d' % (w, h, x, y))
    fen2.title("Mise")
    fen2.overrideredirect(True)

    text=Label(fen2,text="Combien voulez-vous parier ?")
    text.place(relx=.5, rely=.15, anchor="c")

    def recuperation():
        global mise,argent,can,fen1,carte,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,bouton_carte,bouton_rester,bouton_double_mise,mise_initiale

        x=float(entree.get())
        if x>joueur["argent"] or x==0 or x<0:
            if x>joueur["argent"]:
                fen2.attributes('-topmost',0)
                messagebox.showwarning("Attention","Vous ne pouvez pas miser plus que ce que vous avez")
                fen2.attributes('-topmost', 1)

            if x==0:
                fen2.attributes('-topmost',0)
                messagebox.showwarning("Attention","Vous ne pouvez pas ne rien miser")
                fen2.attributes('-topmost', 1)

            if x<0:
                fen2.attributes('-topmost',0)
                messagebox.showwarning("Attention","Vous ne pouvez pas miser une valeur négative")
                fen2.attributes('-topmost', 1)

        else:
            mise=float(x)
            joueur["argent"]-=mise
            mise_initiale=mise

            can.delete("texte")
            can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte2")

            can.delete("texte3")
            can.create_text(150,555,fill="white",font=("Purisa",14),text="Votre mise: "+str(round(mise,2))+" €",tag="texte4")

            distribuer()

            if mise>joueur["argent"]:
                bouton_double_mise.config(state=DISABLED)

                bouton_carte.config(state="normal")
                bouton_rester.config(state="normal")

                fen2.destroy()

            else:
                bouton_carte.config(state="normal")
                bouton_rester.config(state="normal")

                fen2.destroy()

    entree=Entry(fen2)
    entree.place(relx=.5, rely=.45, anchor="c")

    button=Button(fen2,text="Miser",command=recuperation)
    button.place(relx=.5, rely=.8, anchor="c")

    fen2.attributes('-topmost', 1)
#--------------------------------------

# Intelligence artificielle
def ia():
    global paquet,joueur,croupier,main_croupier,paquet,can,fen1,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,victoires

    while sum(main_croupier)<17:
        carte_croupier()

    if sum(main_croupier)>=17:
        perdre_ou_gagner()
#--------------------------------------

# Fait perdre ou gagner le joueur
def perdre_ou_gagner():
    global main_joueur,main_croupier,mise,fen1,fen4,paquet,can,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,victoires

    while joueur["perdu"]==False or joueur["gagne"]==False or joueur["egalite"]==False:

        if sum(main_joueur)>21:
            joueur["perdu"]=True
            mise=0

            if joueur["argent"]==0:
                can.delete("texte4")
                can.delete("texte2")
                can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

                fen4=Tk()

                w=300
                h=90

                ws=fen4.winfo_screenwidth()
                hs=fen4.winfo_screenheight()

                x = (ws/2) - (w/2)
                y = (hs/2) - (h/2)

                fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
                fen4.title("Fauché")
                fen4.overrideredirect(True)

                text=Label(fen4,text="Vous n'avez plus d'argent à parier ! Vous avez perdu !")
                text.place(relx=.5, rely=.15, anchor="c")

                def recommencer():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                    lancer_partie()

                def quitter():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                button_recommencer=Button(fen4,text="Recommencer",command=recommencer)
                button_recommencer.place(relx=.35, rely=.6, anchor="c")
                button_quitter=Button(fen4,text="Quitter",command=quitter)
                button_quitter.place(relx=.65, rely=.6, anchor="c")

                break

            else:
                can.delete("texte4")
                can.delete("texte2")
                can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

                fen4=Tk()

                w=350
                h=90

                ws=fen4.winfo_screenwidth()
                hs=fen4.winfo_screenheight()

                x = (ws/2) - (w/2)
                y = (hs/2) - (h/2)

                fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
                fen4.title("Continuer ?")
                fen4.overrideredirect(True)

                text=Label(fen4,text="Vous avez perdu cette manche. Voulez-vous continuer à jouer ?")
                text.place(relx=.5, rely=.15, anchor="c")

                def quitter():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
                button_oui.place(relx=.35, rely=.6, anchor="c")
                button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
                button_non.place(relx=.65, rely=.6, anchor="c")

                break

        if sum(main_croupier)>21:
            joueur["gagne"]=True
            joueur["argent"]+=mise+mise
            mise=0

            victoires+=1

            can.delete("texte4")
            can.delete("texte2")
            can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

            can.delete("victoires")
            can.create_text(150,585,fill="white",font=("Purisa",14),text="Vos victoires: "+str(victoires),tag="victoires")

            fen4=Tk()

            w=350
            h=90

            ws=fen4.winfo_screenwidth()
            hs=fen4.winfo_screenheight()

            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)

            fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
            fen4.title("Continuer ?")
            fen4.overrideredirect(True)

            text=Label(fen4,text="Vous avez gagné cette manche. Voulez-vous continuer à jouer ?")
            text.place(relx=.5, rely=.15, anchor="c")

            def quitter():
                global fen1,fen4

                fen1.destroy()
                fen4.destroy()

            button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
            button_oui.place(relx=.35, rely=.6, anchor="c")
            button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
            button_non.place(relx=.65, rely=.6, anchor="c")

            break

        if sum(main_joueur)<sum(main_croupier):
            joueur["perdu"]=True
            mise=0

            if joueur["argent"]==0:
                can.delete("texte4")
                can.delete("texte2")
                can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

                fen4=Tk()

                w=300
                h=90

                ws=fen4.winfo_screenwidth()
                hs=fen4.winfo_screenheight()

                x = (ws/2) - (w/2)
                y = (hs/2) - (h/2)

                fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
                fen4.title("Fauché")
                fen4.overrideredirect(True)

                text=Label(fen4,text="Vous n'avez plus d'argent à parier ! Vous avez perdu !")
                text.place(relx=.5, rely=.15, anchor="c")

                def recommencer():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                    lancer_partie()

                def quitter():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                button_recommencer=Button(fen4,text="Recommencer",command=recommencer)
                button_recommencer.place(relx=.35, rely=.6, anchor="c")
                button_quitter=Button(fen4,text="Quitter",command=quitter)
                button_quitter.place(relx=.65, rely=.6, anchor="c")

                break

            else:
                can.delete("texte4")
                can.delete("texte2")
                can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

                fen4=Tk()

                w=350
                h=90

                ws=fen4.winfo_screenwidth()
                hs=fen4.winfo_screenheight()

                x = (ws/2) - (w/2)
                y = (hs/2) - (h/2)

                fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
                fen4.title("Continuer ?")
                fen4.overrideredirect(True)

                text=Label(fen4,text="Vous avez perdu cette manche. Voulez-vous continuer à jouer ?")
                text.place(relx=.5, rely=.15, anchor="c")

                def quitter():
                    global fen1,fen4

                    fen1.destroy()
                    fen4.destroy()

                button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
                button_oui.place(relx=.35, rely=.6, anchor="c")
                button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
                button_non.place(relx=.65, rely=.6, anchor="c")

                break

        if sum(main_joueur)==21:
            joueur["gagne"]=True
            joueur["argent"]+=mise+1.5*mise
            mise=0

            victoires+=1

            can.delete("texte4")
            can.delete("texte2")
            can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

            can.delete("victoires")
            can.create_text(150,585,fill="white",font=("Purisa",14),text="Vos victoires: "+str(victoires),tag="victoires")

            fen4=Tk()

            w=350
            h=90

            ws=fen4.winfo_screenwidth()
            hs=fen4.winfo_screenheight()

            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)

            fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
            fen4.title("Continuer ?")
            fen4.overrideredirect(True)

            text=Label(fen4,text="Vous avez gagné cette manche. Voulez-vous continuer à jouer ?")
            text.place(relx=.5, rely=.15, anchor="c")

            def quitter():
                global fen1,fen4

                fen1.destroy()
                fen4.destroy()

            button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
            button_oui.place(relx=.35, rely=.6, anchor="c")
            button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
            button_non.place(relx=.65, rely=.6, anchor="c")

            break

        if sum(main_joueur)>sum(main_croupier):
            joueur["gagne"]=True
            joueur["argent"]+=mise+mise
            mise=0

            victoires+=1

            can.delete("texte4")
            can.delete("texte2")
            can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

            can.delete("victoires")
            can.create_text(150,585,fill="white",font=("Purisa",14),text="Vos victoires: "+str(victoires),tag="victoires")

            fen4=Tk()

            w=350
            h=90

            ws=fen4.winfo_screenwidth()
            hs=fen4.winfo_screenheight()

            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)

            fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
            fen4.title("Continuer ?")
            fen4.overrideredirect(True)

            text=Label(fen4,text="Vous avez gagné cette manche. Voulez-vous continuer à jouer ?")
            text.place(relx=.5, rely=.15, anchor="c")

            def quitter():
                global fen1,fen4

                fen1.destroy()
                fen4.destroy()

            button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
            button_oui.place(relx=.35, rely=.6, anchor="c")
            button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
            button_non.place(relx=.65, rely=.6, anchor="c")

            break

        if sum(main_joueur)==sum(main_croupier):
            joueur["egalite"]=True
            joueur["argent"]+=mise
            mise=0

            can.delete("texte4")
            can.delete("texte2")
            can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

            fen4=Tk()

            w=350
            h=90

            ws=fen4.winfo_screenwidth()
            hs=fen4.winfo_screenheight()

            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)

            fen4.geometry('%dx%d+%d+%d' % (w, h, x, y))
            fen4.title("Continuer ?")
            fen4.overrideredirect(True)

            text=Label(fen4,text="C'est une égalité. Voulez-vous continuer à jouer ?")
            text.place(relx=.5, rely=.15, anchor="c")

            def quitter():
                global fen1,fen4

                fen1.destroy()
                fen4.destroy()

            button_oui=Button(fen4,text="Oui",font=("Purisa",11),command=continuer_partie)
            button_oui.place(relx=.35, rely=.6, anchor="c")
            button_non=Button(fen4,text="Non",font=("Purisa",11),command=quitter)
            button_non.place(relx=.65, rely=.6, anchor="c")

            break
#--------------------------------------

# Lancer une partie
def lancer_partie():
    global joueur,argent,croupier,main_joueur,main_croupier,mise,fen1,can,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,as_de_pic,as_de_coeur,as_de_trefle,as_de_carreau,deux_de_coeur,deux_de_pic,deux_de_trefle,deux_de_carreau,trois_de_pic,trois_de_coeur,trois_de_trefle,trois_de_carreau,quatre_de_pic,quatre_de_coeur,quatre_de_trefle,quatre_de_carreau,cinq_de_pic,cinq_de_coeur,cinq_de_trefle,cinq_de_carreau,six_de_pic,six_de_coeur,six_de_trefle,six_de_carreau,sept_de_pic,sept_de_coeur,sept_de_trefle,sept_de_carreau,huit_de_pic,huit_de_coeur,huit_de_trefle,huit_de_carreau,neuf_de_pic,neuf_de_coeur,neuf_de_trefle,neuf_de_carreau,dix_de_pic,dix_de_coeur,dix_de_trefle,dix_de_carreau,valet_de_pic,valet_de_coeur,valet_de_trefle,valet_de_carreau,reine_de_pic,reine_de_coeur,reine_de_trefle,reine_de_carreau,roi_de_pic,roi_de_coeur,roi_de_trefle,roi_de_carreau,c,c2,j,j2,argent,bouton_carte,bouton_rester,bouton_double_mise,victoires

    fen1=Tk()

    w=1000
    h=600

    ws=fen1.winfo_screenwidth()
    hs=fen1.winfo_screenheight()

    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)

    fen1.geometry('%dx%d+%d+%d' % (w, h, x, y))
    fen1.title("Blackjack")

    can=Canvas(fen1,width=1000,height=600,background="darkgreen")
    can.place(relx=.5,rely=.5,anchor="c")

    can.create_text(500,570,fill="white",font=("Purisa",14),text="Votre main")
    can.create_text(500,25,fill="white",font=("Purisa",14),text="Main du croupier")

    bouton_carte=Button(fen1,text="Carte",font=("Purisa",14),command=carte_joueur,anchor=CENTER,state=DISABLED)
    bouton_carte.configure(width=5,activebackground="#33B5E5",relief=FLAT)
    bouton_carte_window=can.create_window(25,465,anchor=NW,window=bouton_carte)

    bouton_rester=Button(fen1,text="Rester",font=("Purisa",14),command=ia,anchor=CENTER,state=DISABLED)
    bouton_rester.configure(width=5,activebackground="#33B5E5",relief=FLAT)
    bouton_rester_window=can.create_window(215,465,anchor=NW,window=bouton_rester)

    bouton_double_mise=Button(fen1,text="Double mise",font=("Purisa",14),command=double_mise,anchor=CENTER,state=DISABLED)
    bouton_double_mise.configure(width=9,activebackground="#33B5E5",relief=FLAT)
    bouton_double_mise_window=can.create_window(98,465,anchor=NW,window=bouton_double_mise)

    # Variables de cartes
    as_de_carreau = PhotoImage(file="as_de_carreau.png")
    as_de_coeur = PhotoImage(file="as_de_coeur.png")
    as_de_pic = PhotoImage(file="as_de_pic.png")
    as_de_trefle = PhotoImage(file="as_de_trefle.png")

    deux_de_carreau = PhotoImage(file="2_de_carreau.png")
    deux_de_coeur = PhotoImage(file="2_de_coeur.png")
    deux_de_pic = PhotoImage(file="2_de_pic.png")
    deux_de_trefle = PhotoImage(file="2_de_trefle.png")

    trois_de_carreau = PhotoImage(file="3_de_carreau.png")
    trois_de_coeur = PhotoImage(file="3_de_coeur.png")
    trois_de_pic = PhotoImage(file="3_de_pic.png")
    trois_de_trefle = PhotoImage(file="3_de_trefle.png")

    quatre_de_carreau = PhotoImage(file="4_de_carreau.png")
    quatre_de_coeur = PhotoImage(file="4_de_coeur.png")
    quatre_de_pic = PhotoImage(file="4_de_pic.png")
    quatre_de_trefle = PhotoImage(file="4_de_trefle.png")

    cinq_de_carreau = PhotoImage(file="5_de_carreau.png")
    cinq_de_coeur = PhotoImage(file="5_de_coeur.png")
    cinq_de_pic = PhotoImage(file="5_de_pic.png")
    cinq_de_trefle = PhotoImage(file="5_de_trefle.png")

    six_de_carreau = PhotoImage(file="6_de_carreau.png")
    six_de_coeur = PhotoImage(file="6_de_coeur.png")
    six_de_pic = PhotoImage(file="6_de_pic.png")
    six_de_trefle = PhotoImage(file="6_de_trefle.png")

    sept_de_carreau = PhotoImage(file="7_de_carreau.png")
    sept_de_coeur = PhotoImage(file="7_de_coeur.png")
    sept_de_pic = PhotoImage(file="7_de_pic.png")
    sept_de_trefle = PhotoImage(file="7_de_trefle.png")

    huit_de_carreau = PhotoImage(file="8_de_carreau.png")
    huit_de_coeur = PhotoImage(file="8_de_coeur.png")
    huit_de_pic = PhotoImage(file="8_de_pic.png")
    huit_de_trefle = PhotoImage(file="8_de_trefle.png")

    neuf_de_carreau = PhotoImage(file="9_de_carreau.png")
    neuf_de_coeur = PhotoImage(file="9_de_coeur.png")
    neuf_de_pic = PhotoImage(file="9_de_pic.png")
    neuf_de_trefle = PhotoImage(file="9_de_trefle.png")

    dix_de_carreau = PhotoImage(file="10_de_carreau.png")
    dix_de_coeur = PhotoImage(file="10_de_coeur.png")
    dix_de_pic = PhotoImage(file="10_de_pic.png")
    dix_de_trefle = PhotoImage(file="10_de_trefle.png")
    valet_de_carreau = PhotoImage(file="valet_de_carreau.png")
    valet_de_coeur = PhotoImage(file="valet_de_coeur.png")
    valet_de_pic = PhotoImage(file="valet_de_pic.png")
    valet_de_trefle = PhotoImage(file="valet_de_trefle.png")
    reine_de_carreau = PhotoImage(file="reine_de_carreau.png")
    reine_de_coeur = PhotoImage(file="reine_de_coeur.png")
    reine_de_pic = PhotoImage(file="reine_de_pic.png")
    reine_de_trefle = PhotoImage(file="reine_de_trefle.png")
    roi_de_carreau = PhotoImage(file="roi_de_carreau.png")
    roi_de_coeur = PhotoImage(file="roi_de_coeur.png")
    roi_de_pic = PhotoImage(file="roi_de_pic.png")
    roi_de_trefle = PhotoImage(file="roi_de_trefle.png")
    #--------------------------------------
    cartes_1=[as_de_pic,as_de_coeur,as_de_trefle,as_de_carreau]
    cartes_2=[deux_de_pic,deux_de_coeur,deux_de_trefle,deux_de_carreau]
    cartes_3=[trois_de_pic,trois_de_coeur,trois_de_trefle,trois_de_carreau]
    cartes_4=[quatre_de_pic,quatre_de_coeur,quatre_de_trefle,quatre_de_carreau]
    cartes_5=[cinq_de_pic,cinq_de_coeur,cinq_de_trefle,cinq_de_carreau]
    cartes_6=[six_de_pic,six_de_coeur,six_de_trefle,six_de_carreau]
    cartes_7=[sept_de_pic,sept_de_coeur,sept_de_trefle,sept_de_carreau]
    cartes_8=[huit_de_pic,huit_de_coeur,huit_de_trefle,huit_de_carreau]
    cartes_9=[neuf_de_pic,neuf_de_coeur,neuf_de_trefle,neuf_de_carreau]
    cartes_10=[dix_de_pic,dix_de_coeur,dix_de_trefle,dix_de_carreau,valet_de_pic,valet_de_coeur,valet_de_trefle,valet_de_carreau,reine_de_pic,reine_de_coeur,reine_de_trefle,reine_de_carreau,roi_de_pic,roi_de_coeur,roi_de_trefle,roi_de_carreau]

    creer_participants()

    def argent():
        global joueur,argent,fen5,fen2

        fen5=Tk()

        w=275
        h=90

        ws=fen5.winfo_screenwidth()
        hs=fen5.winfo_screenheight()

        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)

        fen5.geometry('%dx%d+%d+%d' % (w, h, x, y))
        fen5.title("Argent")
        fen5.overrideredirect(True)

        text=Label(fen5,text="Avec combien d'euros voulez-vous jouer ?")
        text.place(relx=.5, rely=.15, anchor="c")

        def recuperer():
            global argent,joueur,fen5,fen2

            x=float(entree.get())

            if x==0 or x<0:
                fen5.attributes('-topmost',0)
                fen2.attributes("-topmost",0)
                messagebox.showwarning("Attention","Vous ne pouvez pas jouer sans argent")
                fen2.attributes('-topmost', 1)
                fen5.attributes("-topmost",1)

            else:
                argent=float(x)
                joueur["argent"]=argent

                can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

                fen5.destroy()

        entree=Entry(fen5)
        entree.place(relx=.5, rely=.45, anchor="c")

        button=Button(fen5,text="Jouer",command=recuperer)
        button.place(relx=.5, rely=.8, anchor="c")

        fen5.attributes('-topmost', 1)

    joueur["main"]=[]
    main_joueur=[]

    joueur["perdu"]=False
    joueur["gagne"]=False
    joueur["egalite"]=False

    croupier["main"]=[]
    main_croupier=[]

    paquet=[1,2,3,4,5,6,7,8,9,10,10,10,10]*4

    c=300
    c2=50
    j=300
    j2=450
    victoires=0

    argent()
    miser()

    fen1.mainloop()
#--------------------------------------

# Continuer la partie
def continuer_partie():
    global joueur,argent,croupier,main_joueur,main_croupier,mise,fen1,fen4,can,paquet,cartes_1,cartes_2,cartes_3,cartes_4,cartes_5,cartes_6,cartes_7,cartes_8,cartes_9,cartes_10,as_de_pic,as_de_coeur,as_de_trefle,as_de_carreau,deux_de_coeur,deux_de_pic,deux_de_trefle,deux_de_carreau,trois_de_pic,trois_de_coeur,trois_de_trefle,trois_de_carreau,quatre_de_pic,quatre_de_coeur,quatre_de_trefle,quatre_de_carreau,cinq_de_pic,cinq_de_coeur,cinq_de_trefle,cinq_de_carreau,six_de_pic,six_de_coeur,six_de_trefle,six_de_carreau,sept_de_pic,sept_de_coeur,sept_de_trefle,sept_de_carreau,huit_de_pic,huit_de_coeur,huit_de_trefle,huit_de_carreau,neuf_de_pic,neuf_de_coeur,neuf_de_trefle,neuf_de_carreau,dix_de_pic,dix_de_coeur,dix_de_trefle,dix_de_carreau,valet_de_pic,valet_de_coeur,valet_de_trefle,valet_de_carreau,reine_de_pic,reine_de_coeur,reine_de_trefle,reine_de_carreau,roi_de_pic,roi_de_coeur,roi_de_trefle,roi_de_carreau,c,c2,j,j2,bouton_carte,bouton_rester,victoires,bouton_double_mise

    fen4.destroy()

    can.destroy()

    can=Canvas(fen1,width=1000,height=600,background="darkgreen")
    can.place(relx=.5,rely=.5,anchor="c")

    can.create_text(500,570,fill="white",font=("Purisa",14),text="Votre main")
    can.create_text(500,25,fill="white",font=("Purisa",14),text="Main du croupier")
    can.create_text(150,525,fill="white",font=("Purisa",14),text="Votre argent: "+str(round(joueur["argent"],2))+" €",tag="texte")

    if victoires>0:
        can.create_text(150,585,fill="white",font=("Purisa",14),text="Vos victoires: "+str(victoires),tag="victoires")

    can.delete("texte4")

    bouton_carte=Button(fen1,text="Carte",font=("Purisa",14),command=carte_joueur,anchor=CENTER,state=DISABLED)
    bouton_carte.configure(width=5,activebackground="#33B5E5",relief=FLAT)
    bouton_carte_window=can.create_window(25,465,anchor=NW,window=bouton_carte)

    bouton_rester=Button(fen1,text="Rester",font=("Purisa",14),command=ia,anchor=CENTER,state=DISABLED)
    bouton_rester.configure(width=5,activebackground="#33B5E5",relief=FLAT)
    bouton_rester_window=can.create_window(215,465,anchor=NW,window=bouton_rester)

    bouton_double_mise=Button(fen1,text="Double mise",font=("Purisa",14),command=double_mise,anchor=CENTER,state=DISABLED)
    bouton_double_mise.configure(width=9,activebackground="#33B5E5",relief=FLAT)
    bouton_double_mise_window=can.create_window(98,465,anchor=NW,window=bouton_double_mise)

    # Variables de cartes
    as_de_carreau = PhotoImage(file="as_de_carreau.png")
    as_de_coeur = PhotoImage(file="as_de_coeur.png")
    as_de_pic = PhotoImage(file="as_de_pic.png")
    as_de_trefle = PhotoImage(file="as_de_trefle.png")

    deux_de_carreau = PhotoImage(file="2_de_carreau.png")
    deux_de_coeur = PhotoImage(file="2_de_coeur.png")
    deux_de_pic = PhotoImage(file="2_de_pic.png")
    deux_de_trefle = PhotoImage(file="2_de_trefle.png")

    trois_de_carreau = PhotoImage(file="3_de_carreau.png")
    trois_de_coeur = PhotoImage(file="3_de_coeur.png")
    trois_de_pic = PhotoImage(file="3_de_pic.png")
    trois_de_trefle = PhotoImage(file="3_de_trefle.png")

    quatre_de_carreau = PhotoImage(file="4_de_carreau.png")
    quatre_de_coeur = PhotoImage(file="4_de_coeur.png")
    quatre_de_pic = PhotoImage(file="4_de_pic.png")
    quatre_de_trefle = PhotoImage(file="4_de_trefle.png")

    cinq_de_carreau = PhotoImage(file="5_de_carreau.png")
    cinq_de_coeur = PhotoImage(file="5_de_coeur.png")
    cinq_de_pic = PhotoImage(file="5_de_pic.png")
    cinq_de_trefle = PhotoImage(file="5_de_trefle.png")

    six_de_carreau = PhotoImage(file="6_de_carreau.png")
    six_de_coeur = PhotoImage(file="6_de_coeur.png")
    six_de_pic = PhotoImage(file="6_de_pic.png")
    six_de_trefle = PhotoImage(file="6_de_trefle.png")

    sept_de_carreau = PhotoImage(file="7_de_carreau.png")
    sept_de_coeur = PhotoImage(file="7_de_coeur.png")
    sept_de_pic = PhotoImage(file="7_de_pic.png")
    sept_de_trefle = PhotoImage(file="7_de_trefle.png")

    huit_de_carreau = PhotoImage(file="8_de_carreau.png")
    huit_de_coeur = PhotoImage(file="8_de_coeur.png")
    huit_de_pic = PhotoImage(file="8_de_pic.png")
    huit_de_trefle = PhotoImage(file="8_de_trefle.png")

    neuf_de_carreau = PhotoImage(file="9_de_carreau.png")
    neuf_de_coeur = PhotoImage(file="9_de_coeur.png")
    neuf_de_pic = PhotoImage(file="9_de_pic.png")
    neuf_de_trefle = PhotoImage(file="9_de_trefle.png")

    dix_de_carreau = PhotoImage(file="10_de_carreau.png")
    dix_de_coeur = PhotoImage(file="10_de_coeur.png")
    dix_de_pic = PhotoImage(file="10_de_pic.png")
    dix_de_trefle = PhotoImage(file="10_de_trefle.png")
    valet_de_carreau = PhotoImage(file="valet_de_carreau.png")
    valet_de_coeur = PhotoImage(file="valet_de_coeur.png")
    valet_de_pic = PhotoImage(file="valet_de_pic.png")
    valet_de_trefle = PhotoImage(file="valet_de_trefle.png")
    reine_de_carreau = PhotoImage(file="reine_de_carreau.png")
    reine_de_coeur = PhotoImage(file="reine_de_coeur.png")
    reine_de_pic = PhotoImage(file="reine_de_pic.png")
    reine_de_trefle = PhotoImage(file="reine_de_trefle.png")
    roi_de_carreau = PhotoImage(file="roi_de_carreau.png")
    roi_de_coeur = PhotoImage(file="roi_de_coeur.png")
    roi_de_pic = PhotoImage(file="roi_de_pic.png")
    roi_de_trefle = PhotoImage(file="roi_de_trefle.png")
    #--------------------------------------
    cartes_1=[as_de_pic,as_de_coeur,as_de_trefle,as_de_carreau]
    cartes_2=[deux_de_pic,deux_de_coeur,deux_de_trefle,deux_de_carreau]
    cartes_3=[trois_de_pic,trois_de_coeur,trois_de_trefle,trois_de_carreau]
    cartes_4=[quatre_de_pic,quatre_de_coeur,quatre_de_trefle,quatre_de_carreau]
    cartes_5=[cinq_de_pic,cinq_de_coeur,cinq_de_trefle,cinq_de_carreau]
    cartes_6=[six_de_pic,six_de_coeur,six_de_trefle,six_de_carreau]
    cartes_7=[sept_de_pic,sept_de_coeur,sept_de_trefle,sept_de_carreau]
    cartes_8=[huit_de_pic,huit_de_coeur,huit_de_trefle,huit_de_carreau]
    cartes_9=[neuf_de_pic,neuf_de_coeur,neuf_de_trefle,neuf_de_carreau]
    cartes_10=[dix_de_pic,dix_de_coeur,dix_de_trefle,dix_de_carreau,valet_de_pic,valet_de_coeur,valet_de_trefle,valet_de_carreau,reine_de_pic,reine_de_coeur,reine_de_trefle,reine_de_carreau,roi_de_pic,roi_de_coeur,roi_de_trefle,roi_de_carreau]

    joueur["main"]=[]
    main_joueur=[]

    joueur["perdu"]=False
    joueur["gagne"]=False
    joueur["egalite"]=False

    croupier["main"]=[]
    main_croupier=[]

    paquet=[1,2,3,4,5,6,7,8,9,10,10,10,10]*4

    c=300
    c2=50
    j=300
    j2=450

    miser()
#--------------------------------------

lancer_partie()
