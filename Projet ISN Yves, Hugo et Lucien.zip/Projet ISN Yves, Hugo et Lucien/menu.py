from tkinter import *

menu=Tk()

w=300
h=100

ws=menu.winfo_screenwidth()
hs=menu.winfo_screenheight()

x = (ws/2) - (w/2)
y = (hs/2) - (h/2)

menu.geometry('%dx%d+%d+%d' % (w, h, x, y))
menu.title("Menu principal")

text=Label(menu,text="A quel jeu voulez-vous jouer ?",font=("Purisa",12))
text.place(relx=.5,rely=.15,anchor="c")

def poker():
    import os

    x=os.path.dirname(os.path.realpath("programme.py"))

    os.chdir(x)
    os.startfile("programme.py")

def blackjack():
    import os

    x=os.path.dirname(os.path.realpath("blackjack.py"))

    os.chdir(x)
    os.startfile("blackjack.py")

    #os.system('python blackjack.py')

bouton_poker=Button(menu,text="Poker",font=("Purisa",14),command=poker,anchor=CENTER)
bouton_poker.place(relx=.3,rely=.55,anchor="c")

bouton_blackjack=Button(menu,text="Blackjack",font=("Purisa",14),command=blackjack,anchor=CENTER)
bouton_blackjack.place(relx=.65,rely=.55,anchor="c")

menu.mainloop()
